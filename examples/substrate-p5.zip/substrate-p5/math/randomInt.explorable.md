# this is an importable

This explorable module can be imported from other explorables

```js
export default function randomInt (a, b) {
    return a + Math.floor(Math.random() * (b-a))
}
```

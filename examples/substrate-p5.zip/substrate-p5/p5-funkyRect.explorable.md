
# FunkyRect class

A funky rectangle! Is there more to say?

Okay, so this is a class for drawing a (funky) rectangle to a p5 canvas. It's funky in that it transitions to a target position + size in a wobbly way.

For the sake of documentation, this class' methods are added to the class after defining it.


## constructor

Creates a new FunkyRect instance with given x, y, width, height and color.

```js
class FunkyRect {
    constructor(x,y,width,height,r=255,g=255,b=255,a=255){
        this.base = {x,y,width,height}
        this.target = {x,y,width,height}
        this.current = {x,y,width,height}
        this.speed = {x:0,y:0,width:0,height:0}
        this.color = {r,g,b,a}
    }
}
```

## randomize

Sets this rect's target x, y, width and height to a random value in a given range relative to its base coordinates.

```js
FunkyRect.prototype.randomize = function(amp=20){
    for (let a in this.target) {
        this.target[a] = this.base[a] + randomInt(-amp,amp)
    }
}
```
## draw

Draw this rect to the screen, above its drop shadow. Requires a p5 instance as an argument.

```js
FunkyRect.prototype.draw = function(p){
    for (let a in this.current) {
        const diff = this.target[a] - this.current[a]
        this.speed[a] += diff/30
        this.speed[a] /= 1.1
        this.current[a] += this.speed[a]
    }
    //p5 calls
    const {r,g,b,a} = this.color

    const x = this.current.x-this.current.width/2,
    y = this.current.y-this.current.height/2,
    w = this.current.width,
    h = this.current.height

    // drop shadow
    p.noStroke()
    p.fill(0,0,0,80)
    p.rect(x+12,y+12,w,h)

    // body
    p.noStroke()
    p.fill(r,g,b,a)
    p.rect(x,y,w,h)
}
```
## Example
Click anywhere to randomize the funkyRect's position and size!
```js explorable
const sketch = function(p){
    const rect = new FunkyRect(100,100,100,100)
    p.setup = function(){
        p.createCanvas(200,200)
    }
    p.draw = function(){
        p.background(150,200,255)
        rect.draw(p)
    }
    p.mouseClicked = function(){
        rect.randomize()
    }
}
const ph = new P5Helper(sketch);
html`
<div>
    <div @hook:insert=${ph.insert.bind(ph)}></div>
</div>`
```
## Output
```js
export default FunkyRect
```
## Dependencies
```js
import {randomInt} from './math/math.explorable.md'
```
Dependencies hidden in the explorable block below are only used to display the example. We don't need them to be part of this document's output.
```javascript explorable
import P5Helper     from './p5-helper.explorable.md'
import html         from 'https://cdn.skypack.dev/snabby'
```
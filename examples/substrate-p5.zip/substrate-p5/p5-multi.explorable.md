# p5 multiple instances demo

This document imports a p5 sketch from _p5-example_, and initializes multiple instances of it in explorable blocks. They are truly unique instances in that they don't share variables and behave independently.

Indeed, clicking any of them pauses / unpauses its own rotation movement.

```js explorable
const ph = new P5Helper(sketch)
html`
<div>
    <div @hook:insert=${ph.insert.bind(ph)}></div>
</div>`
```
```js explorable
const ph = new P5Helper(sketch)
html`
<div>
    <div @hook:insert=${ph.insert.bind(ph)}></div>
</div>`
```

## Dependencies
Here, all dependencies are inside an explorable block, as none is relevant to this document's output. Actually, since this document is just for show and actually exports nothing, it wouldn't change anything to place import statements inside a regular JavaScript block instead.

Also, as a reminder: import statements can't be inside an explorable block containing a view. That's why we can't just add them to the blocks above.

```js explorable
import sketch       from './p5-example.explorable.md'
import P5Helper     from './p5-helper.explorable.md'
import html     from 'https://cdn.skypack.dev/snabby'
```

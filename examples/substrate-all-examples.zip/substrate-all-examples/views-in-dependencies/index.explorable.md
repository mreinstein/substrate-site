# Interactive views

```js

function incrementButtonCount(){
    console.log(arguments)
    state.buttonCount ++;
    update();
}

function _insertHook(vnode){
    Renderer.ctx = vnode.elm.getContext('2d')
    requestAnimationFrame(gameLoop)
}

function gameLoop(elapsedMS){
    console.log('renderScene index!')
    renderScene(elapsedMS/1000)
    requestAnimationFrame(gameLoop)
}
```

```js explorable
html`<div>
    <style>${css}</style>
    <canvas width="${Renderer.width}"
        height="${Renderer.height}"
        @hook:insert=${_insertHook}
        style="background: linear-gradient(45deg, rgb(86 160 255) 0%, rgb(21, 64, 139) 100%)">
    </canvas>
    <h3>woah, the button's been clicked ${state.buttonCount} times</h3>
    <button @on:click=${incrementButtonCount}>click me!</button>
</div>`
```

## Imports

```js
import html from 'https://cdn.skypack.dev/snabby'
import css from './styles.css'
import {Renderer, state} from './lib/globals.explorable.md'
import renderScene from './lib/renderScene.explorable.md'
```
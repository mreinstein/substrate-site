# p5.js example

This example relies on the p5 library, which facilitates visual, moving, interactive experiments through creative coding.

This document pulls together components imported from other documents, into a complete p5 project or 'sketch'.

---

## Sketch function and variables

To keep things modular, and variables away from the global scope, we use p5 in instance mode. This sketch will be initialized by creating a new p5 instance with one parameter, `sketch`.

```js
const sketch = function(p) {
    p._rects = [];
    p._rotation = 0;
    p._rotating = true;
    p.setup = getSetup(p)
    p.draw = getDraw(p)
    //// pause / upause the rotation on click
    p.mouseClicked = function(){
        if (p.mouseX >=0 && p.mouseX <= 400 &&
            p.mouseY >=0 && p.mouseY <= 400
        ){
            p._rotating = !p._rotating
        }
    }
}
```

`sketch` is a function which, when called, will define the __setup__, __draw__ and __mouseClicked__ functions of the p5 instance.

We also initialize our sketch-related variables in there.
* ___rect__ is an Array to hold multiple _FunkyRect_ instances
* ___rotation__ stores the rotation angle applied to the whole sketch

__setup__ and __draw__ could have been defined directly inside the `sketch` function. However, defining them as the result of function calls allows us to organize code better and insert documentation inbetween.

Consequently, sketch variables have to be attached to the p5 instance `p`, which is passed to `getSetup` and `getDraw`, for setup and draw to access them.

---

## Setup function

This function will run once, when the sketch starts.

We create the canvas and define its size, then we push a bunch of `FunkyRect` instances to `_rects`.

```js
const getSetup = function(p) {
    return function() {
        p.createCanvas(400, 400);
        for (let i=0; i<100; i++) {
            p._rects.push(new FunkyRect(
                randomInt(0,400),
                randomInt(0,400),
                randomInt(50,100),
                randomInt(50,100),
                randomInt(255,255),
                randomInt(255,255),
                randomInt(255,255),
                255
            ))
        }
    }
}
```
---

## Draw function

This function will be called every time p5 redraws the sketch to its canvas. It is, to put it simply, our 'game loop'.

```js
const getDraw = function(p) {
    return function() {
        p.background(255)
        p.push()
        p.translate(200,200)
        if (p._rotating) {
            p._rotation += Math.PI/400
        }
        p.rotate(p._rotation)
        p.translate(-200,-200)
        //////////////
        drawRects(p)
        //////////////
        p.pop()
        p.noFill()
        p.stroke(0,0,0,150)
        p.circle(p.mouseX,p.mouseY,100,100)
    }
}
```

A lot happens here:

* The canvas is filled with a background color.
* `_o.rotation` is incremented, and that rotation angle is applied to the transform matrix.
* Every `FunkyRect` instance in `_o.rects` is updated and redrawn. Aditionnally, each funkyRect has a small chance of having it's target position and size randomized.
* Because of the rotation we've applied to the transform matrix, the whole sketch is drawn rotated. The calls to `p.translate()` serve to define the rotation's pivot point. `p.push()` saves the current state of the transform matrix and `p.pop()` restores it.
* A circle is drawn at the mouse pointer's position. Since it's drawn after `p.pop()`, it's not affected by the rotation.

---
## drawRects(p)
Extra functions may be defined for further code splitting. They can be defined in the document's root, as long as they receive our p5 instance as an argument if they are to use p5 functions or manipulate sketch variables.
```js
const drawRects = function(p) {
    p._rects.forEach(r => {
        if (Math.random()<0.01) r.randomize(20)
        r.draw(p);
    })
}
```
---
## Rendering the sketch in a document's view
Inside the following explorable block, an helper class, `P5Helper`, serves two purposes:

* Initializing a new instance of p5 with our `sketch` function as an argument 
* Inserting this instance's canvas element into the block's view

The result is our live, interactive sketch, running right here!

**Click the sketch to pause / unpause its rotation movement.**

```js explorable
const ph = new P5Helper(sketch)
html`
<div>
    <div @hook:insert=${ph.insert.bind(ph)}></div>
</div>`
```

---

## Output

By exporting `sketch`, we're able to reuse it in other documents. We can add it to a view over there, the same concise way it's done above.

Notice that `sketch`, being a function rather than an object, is like of a blueprint of our sketch. When passed to `new p5()`, a completely new instance of the sketch is created. You could initialize the same sketch multiple times in the same document and they would behave independently from each other.

This is well demonstrated in the document _p5-multi_ !

```js
export default sketch
```

---

## Dependencies

```js
import FunkyRect   from './p5-funkyRect.explorable.md'
import {randomInt} from './math/math.explorable.md'
```
```js explorable
import P5Helper    from './p5-helper.explorable.md'
import html     from 'https://cdn.skypack.dev/snabby'
```

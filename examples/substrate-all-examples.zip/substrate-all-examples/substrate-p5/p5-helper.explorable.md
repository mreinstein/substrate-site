# p5.js helper class

This little helper class facilitates the rendering of p5 sketches inside substrate documents.

```js
class P5Helper {
    constructor(sketch) {
        this.p5instance = new p5(sketch)
    }
    insert(vnode) {
        const canvasContainer = vnode.elm;
        let interval = setInterval(()=>{
            if (this.p5instance && this.p5instance.canvas) {
                canvasContainer.appendChild(this.p5instance.canvas);
                clearInterval(interval);
            }
        },100)
    }
}
```

## Example usage
```js explorable
const sketch = function(p){
    let r = 0
    p.setup = function(){
        p.createCanvas(200,200)
        p.background(0)
        p.noStroke()
    }
    p.draw = function(){
        r += Math.PI/50
        p.fill(255,255,255)
        p.circle(
            100+r*Math.sin(r),
            100+r*Math.cos(r),
            2
        )
    }
}
const ph = new P5Helper(sketch);
html`
<div>
    <div @hook:insert=${ph.insert.bind(ph)}></div>
</div>`
```

## Output
```js
export default P5Helper
```

## Dependencies
```js
import p5       from 'https://cdn.skypack.dev/p5'
```
```js explorable
import html     from 'https://cdn.skypack.dev/snabby'
```
```js
import html     from 'https://cdn.skypack.dev/snabby'
import ph        from './phaser-helpers.explorable.md'
```

```js
const preload = function()
{
    // this.load.setBaseURL('https://labs.phaser.io');
    this.load.image('sky', './assets/sky.png');
    this.load.spritesheet('canard', 
        'assets/canard2.png',
        { frameWidth: 120, frameHeight: 108 }
    );
    this.load.spritesheet('panache', 
        'assets/panache.png',
        { frameWidth: 192, frameHeight: 156 }
    );
}
```
```js
const create = function()
{
    console.log('phaser create');

    this.add.image(400, 300, 'sky');

    ////////////////

    const canard = this.physics.add.sprite(200, 0, 'canard');
    canard.setBounce(0.2);
    canard.setCollideWorldBounds(true);

    const panache = this.physics.add.sprite(350, 0, 'panache');
    panache.setBounce(0.2);
    panache.setCollideWorldBounds(true);

    this.anims.create({
        key: 'canard_dance',
        frames: this.anims.generateFrameNumbers('canard', { start: 0, end: 17 }),
        frameRate: 20,
        repeat: -1
    });
    this.anims.create({
        key: 'panache_dance',
        frames: this.anims.generateFrameNumbers('panache', { start: 0, end: 3 }),
        frameRate: 4,
        repeat: -1
    });
    canard.anims.play('canard_dance',true);
    panache.anims.play('panache_dance',true);
}
```
```javascript explorable
ph.setup(preload, create);
html`
<div>
    <div></div>
    <script @hook:insert=${ph.inserted} src="./phaser.min.js">
</div>`
```
```js
const getConfig = function(preload, create){
    return {
        type: 'auto',
        width: 600,
        height: 400,
        physics: {
            default: 'arcade',
            arcade: {
                gravity: { y: 800 }
            }
        },
        scene: {
            preload,
            create
        }
    }
}
const setup = (preload, create) => {
    self.config = getConfig(preload, create)
}
const inserted = vnode => {
    if (!self.config) {
        throw new Error('No config specified!')
    }
    const check = window.setInterval(() => {
        if (window.hasOwnProperty('Phaser')) {
            self.config.type = Phaser.AUTO
            self.config.parent = vnode.elm.parentElement.querySelector
            ('div')
            self.game = new Phaser.Game(self.config)
            window.clearInterval(check)
        }
    }, 100)
}
const self = {
    config:null,
    game:null,
    getConfig,
    setup,
    inserted
}
export default self
```
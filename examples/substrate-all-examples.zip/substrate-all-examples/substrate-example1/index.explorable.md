# A substrate document

Welcome to this example substrate document!

__This is a javascript block:__
```js
const js = "Javascript block here. Doin' great!";
console.log(js);
```

__And this is a javascript *explorable* block:__
```javascript explorable
const explorable = 'Explorable block here. Collapsed, but present.';
console.log(explorable);
```

The code written in both block types will run when this page is viewed. If you open the console now, you should see the output from both.

However, code inside javascript explorable blocks gets _excluded_ from a document's javascript output. It only executes when the document is viewed in Substrate's viewer. __For this reason, javascript explorable blocks are a great place to put code examples.__

If you were to import this document in another document or js file, _you would not see the output from the javascript explorable block_.

---
---

# Importing

This substrate document imports and uses javascript components from other documents.

The banner below, for example, is defined in _banner.explorable.md_.

Here, it's added to an html view by ending a javascript explorable block with an html\`....\` call. This feature, which requires [snabby](https://www.skypack.dev/view/snabby), is very handy to add custom / interactive content to documents.

```javascript explorable
html`<div>${banner}</div>`
```

---
---

# Calling imported functions

_randomInt_, a function used to get a random integer, is also imported here from another document: _math/math.explorable.md_

This function can be called in this document's javascript and javascript explorable blocks, just like it would if this was a regular js file.

```javascript explorable
const randomize = () => {
    randText = math.randomInt(1,99);
    update();
}
html`
<div>
    <style>${css}</style>
    <p>As an example, clicking the button below calls randomInt(1,99) and writes <b>${randText}</b></p>
    <button @on:click=${randomize}>get random integer</button>
</div>`
```
Notice the call to `update()`. This global function can be called whenever the DOM needs to be refreshed.

---
---

# Helpers
_randText_, used to store and display the last randomly generated integer, is not useful outside of this document, but it has to be declared inside a javascript block in order for it to get updated properly.
```js
let randText = 'the result here'
```

---
---

# Dependencies
Javascript will hoist import statements, so they actually don't need to be at the top of the document.
Thus, imports can be placed the end much like references in a more traditional document.

Notice that snabby is imported directly from npm without needing to `npm install`. Thanks, [skypack]('https://cdn.skypack.dev')!

```js
import banner   from './banner.explorable.md'
import * as math     from './math/math.explorable.md'
import css      from './styles.css'
import html     from 'https://cdn.skypack.dev/snabby'
```

# Exports
Since this is a module, let's export something: an object with a random 4 digits number as its sole property.
```javascript
const exportable = {secret: `${math.randomInt(0,9)}${math.randomInt(0,9)}${math.randomInt(0,9)}${math.randomInt(0,9)}`}
export default  exportable
```
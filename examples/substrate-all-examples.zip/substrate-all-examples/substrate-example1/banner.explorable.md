# Define banner

```js
const banner = 
html`<div>
    <style>${css}</style>
    <h1 class="banner">HELLO SUBSTRATE</h1>
</div>`
```

---

# Export

```js
export default banner
```

---

# Dependencies
```js
import html     from 'https://cdn.skypack.dev/snabby'
import css      from './styles.css'
```
# World

An object representing a world of lizards and lava.

```js
const world = {volcanoes:13124, dinosaurs: 7512097}
```

## Exports

```js
export default world
```
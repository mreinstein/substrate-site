#Foo

It's got some incredible properties.

```js
const foo = {
    name: 'Foo',
    amazing: true,
    great: true,
    equilateral: false,
    position: vec2.fromValues(100,200)
}
```
##Export

```js
export default foo
```

##Dependencies
```js
import { vec2 } from 'https://cdn.skypack.dev/gl-matrix'
```
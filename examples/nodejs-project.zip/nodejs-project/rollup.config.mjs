import substrate    from 'rollup-plugin-substrate'
import urlResolve   from 'rollup-plugin-url-resolve'

export default {
    input: 'app.js',
    output: {
        file: 'app-bundle.js'
    },
    plugins: [
        substrate(),
        urlResolve(
            {
                cacheManager: '.cache'
            }
        ),
    ]
}
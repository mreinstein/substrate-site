import foo from './foo.explorable.md'  // a substrate explorable which outputs an es module
import bar  from './bar.js'             // a typical javascript module

document.body.insertAdjacentHTML('beforeend', 
    `<p>${bar(foo.name)}
    <p>Indeed, ${foo.name} is ${foo.position[1]} meters below that bar!`
)

// // create a vec2 representing x/y the distance covered by a jump
// const jumpDistance = vec2.fromValues(0,-1000)

// // increase foo.position by jumpDistance
// vec2.add(foo.position, foo.position, jumpDistance)

// // supplement the story with foo's new y position
// document.body.insertAdjacentHTML('beforeend',
//     `<p>What a jump! Now ${foo.name} is ${-foo.position[1]} meters above the bar. Oh well.`
// )

// // make sure to import vec2 here as well
// import { vec2 } from 'https://cdn.skypack.dev/gl-matrix'
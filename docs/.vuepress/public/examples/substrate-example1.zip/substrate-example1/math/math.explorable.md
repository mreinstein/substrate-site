```javascript
import randomInt from './randomInt.explorable.md'
const pi = Math.PI
export {randomInt, pi}
```
Named exports have to be placed in the javascript block where they're defined!

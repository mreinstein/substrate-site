# Hello Substrate!
This is a **Substrate** document. It is _very_ nice to read.
```js
console.log('hello substrate')
```

### Let's log the number of dinos to the console.

```js
import world from './world.explorable.md'
console.log(world.dinosaurs)
```